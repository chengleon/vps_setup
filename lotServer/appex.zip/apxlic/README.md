# LotServer_KeyGen


Usage: 
  - cli: 
  ```
  php keygen.php mac [ver]
  For example, php keygen.php 00:00:00:00:00:00 1
  ```
  - web:
  ```
  http://example.com/keygen.php?ver=1&mac=00:00:00:00:00:00
  ```
